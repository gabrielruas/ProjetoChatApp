import './App.css';
import {BrowserRouter, Route, Routes} from 'react-router-dom';
import { Home } from './paginas/Home/Home';
import { Usuarios } from './paginas/Usuarios/Usuarios';
import { NovoUsuario } from './paginas/NovoUsuario/NovoUsuario';

function App() {
  return (
   <BrowserRouter>
    <Routes>
        <Route path='/' element={<Home />}/>
        <Route path='/usuarios' element={<Usuarios />}/>
        <Route path='/usuarios/novo' element={<NovoUsuario />}/>
    </Routes>
   </BrowserRouter>
  );
}

export default App;
